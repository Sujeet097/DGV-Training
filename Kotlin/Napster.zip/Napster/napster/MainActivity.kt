package com.example.napster

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val audioViewModel:AudioListViewModel= ViewModelProvider(this).get(AudioListViewModel::class.java)
        val recyclerView=findViewById<RecyclerView>(R.id.myRecyclerView)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter=ListAdapter(this,audioViewModel.songs)

        val songViewModel:AudioListViewModel=ViewModelProvider(this).get(AudioListViewModel::class.java)

        var listAdapter:ListAdapter = ListAdapter(this, audioViewModel.songs)
        recyclerView.adapter=listAdapter

        var genre=intent.getStringExtra("genre")

        var genreList= mutableListOf<Song>()

        for(i in 0 until songViewModel.songs.size){
            if(songViewModel.songs.get(i).genre==genre){
                genreList.add(songViewModel.songs.get(i))
            }
        }
        listAdapter=ListAdapter(this,genreList)
        recyclerView.adapter=listAdapter


    }
}