package com.example.napster

class Song(id:Int,title:String,artist:String,thumbnail:Int,audio:Int,genre:String) {
    var id:Int
    var title:String?=null
    var artist:String?=null
    var thumbnail:Int=0
    var audio:Int
    var genre:String?=null
    var songId:Int=0

    init{
        this.id=id
        this.title=title
        this.artist=artist
        this.thumbnail=thumbnail
        this.audio=audio
        this.genre=genre
        this.songId=songId
    }

}