package com.example.napster

import androidx.lifecycle.ViewModel

class AudioListViewModel : ViewModel(){

    var songs = listOf<Song>(
            Song(1,"Aur Ho","Mohit Chauhan",R.drawable.aur_ho,R.raw.aur_ho,"Romantic"),
            Song(2,"Manike","Yohani",R.drawable.manike,R.raw.manike,"Romantic"),
            Song(3,"Mann Mera","Gajendra Verma",R.drawable.mann_mera,R.raw.mannmera,"Romantic"),
            Song(4,"Maan Meri Jaan","KING",R.drawable.maan_meri_jaan,R.raw.maanmerijaan,"Romantic"),
            Song(5,"Shayad","Arijit Singh",R.drawable.shayad,R.raw.shayad,"Romantic"),
            Song(6,"Tujhse Door Jo Hota Hun","Gajendra Verma",R.drawable.tujhse_door_jo_hota_hu,R.raw.tujhsedoorjohotahun,"Romantic"),
    )
    var genre = listOf<String>(
        "Romantic",
        "Hip-Hop",
        "Punjabi",
        "Bollywood"

    )
}