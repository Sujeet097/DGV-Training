package com.example.napster

import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MusicPlayerActivity : AppCompatActivity() {
    //Runnable and Handler for seekBar
    lateinit var runnable: Runnable
    var handler=Handler()

    //Making mediaPLayer static to access globally
    companion object{
        var mediaPlayer:MediaPlayer?=null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music_player)

        var audioViewModel: AudioListViewModel =
            ViewModelProvider(this).get(AudioListViewModel::class.java)

        //var index = intent.getStringExtra("index")!!.toInt()
        //var song:Song = audioViewModel.songs.get(index!!.toInt())

        var id =intent.getStringExtra("id")!!.toInt()
        var song:Song=audioViewModel.songs.get(0)
        var index=0
        for(i in 0 until audioViewModel.songs.size){
            if(audioViewModel.songs.get(i).id==id){
                song=audioViewModel.songs.get(i)
                index=i
            }
        }

        val mediaPlayer = MediaPlayer.create(this,song.audio)
        mediaPlayer?.start()

        //Conditioin to make prev song from stop playing
        if(mediaPlayer!=null)
        {
            mediaPlayer.stop()
            mediaPlayer.reset()
            mediaPlayer.release()
            mediaPlayer!=null
        }


       //Fetching layout of constraints
        val singleThumbnail = findViewById<ImageView>(R.id.singleThumbnail)
        val singleTitle = findViewById<TextView>(R.id.singleTitle)
        val singleArtist = findViewById<TextView>(R.id.singleArtist)
        val timeleft = findViewById<TextView>(R.id.timeleft)
        val timeright =findViewById<TextView>(R.id.timeright)
        val seekBar= findViewById<SeekBar>(R.id.seekBar)
        val playButton= findViewById<FloatingActionButton>(R.id.playButton)
        val nextButton=findViewById<FloatingActionButton>(R.id.nextBtn)
        val previousButton=findViewById<FloatingActionButton>(R.id.previousButton)

        fun mainPlayer(song: Song) {
            var mediaPlayer = MediaPlayer.create(this, song.audio)
            mediaPlayer?.start()


            singleThumbnail.setImageResource(song.thumbnail)
            singleArtist.text = song.artist
            singleTitle.text = song.title
            seekBar.progress = 0
            seekBar.max = mediaPlayer!!.duration

            playButton.setOnClickListener {

                if (!(mediaPlayer!!.isPlaying)) {
                    mediaPlayer.start()
                    playButton.setImageResource(R.drawable.ic_baseline_pause_24)
                } else {
                    mediaPlayer.pause()
                    playButton.setImageResource(R.drawable.ic_baseline_play_arrow_24)
                }

            }





            seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(p0: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        mediaPlayer.seekTo(progress)
                    }
                    var p1_millisec = progress / 1000
                    var min1 = p1_millisec / 60
                    var sec1 = p1_millisec % 60
                    timeleft.text = min1.toString() + "" + sec1.toString()
                    var p2_millsec = seekBar.max / 1000
                    var min2 = p2_millsec / 60
                    var sec2 = p2_millsec % 60
                    timeright.text = min2.toString() + "" + sec2.toString()
                }

                override fun onStartTrackingTouch(p0: SeekBar?)=Unit

                override fun onStopTrackingTouch(p0: SeekBar?) =Unit

            })
            runnable = Runnable {
                seekBar.progress = mediaPlayer!!.currentPosition
                handler.postDelayed(runnable, 1000)
            }
            handler.postDelayed(runnable, 1000)
            mediaPlayer!!.setOnCompletionListener {
                mediaPlayer.pause()
                playButton.setImageResource(R.drawable.ic_baseline_play_arrow_24)
            }

        }
        mainPlayer(song)

        previousButton.setOnClickListener{
            mediaPlayer?.stop()
            mediaPlayer?.release()

            if(index<=0){
                index=audioViewModel.songs.size-1
            }
            else{
                index++
            }
            song=audioViewModel.songs.get(index)
            mainPlayer(song)
        }

         nextButton.setOnClickListener {
                 mediaPlayer?.stop()
                 mediaPlayer?.release()

             if(index >= (audioViewModel.songs.size-1)){
                 index=0
            }else{
                index++
            }
             song=audioViewModel.songs.get(index)
             mainPlayer(song)
         }




    }
}