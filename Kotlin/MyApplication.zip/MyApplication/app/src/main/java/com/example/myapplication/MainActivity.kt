package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var tv1 =findViewById<TextView>(R.id.tv1)
        var tv2 =findViewById<TextView>(R.id.tv2)
        var tv3 =findViewById<TextView>(R.id.tv3)
        var tv4 =findViewById<TextView>(R.id.tv4)
        var tv5 =findViewById<TextView>(R.id.tv5)
        var tv6 =findViewById<TextView>(R.id.tv6)
        var tv7 =findViewById<TextView>(R.id.tv7)
        var tv8 =findViewById<TextView>(R.id.tv8)
        var tv9 =findViewById<TextView>(R.id.tv9)
        var gameResult=findViewById<TextView>(R.id.gameResult)
        var playBtn=findViewById<TextView>(R.id.playBtn)



        var count:Int=0;
        var game= arrayOf("1","2","3","4","5","6","7","8","9");

        fun checkWin()
        {
            if(
                (game[0]==game[1] && game[1]==game[2])||
                (game[3]==game[4] && game[4]==game[5])||
                (game[6]==game[7] && game[7]==game[8])||
                (game[0]==game[3] && game[3]==game[6])||
                (game[1]==game[4] && game[4]==game[7])||
                (game[2]==game[5] && game[5]==game[8])||
                (game[0]==game[4] && game[4]==game[8])||
                (game[2]==game[4] && game[4]==game[6])
            ){

                  if(count%2==0){
                      gameResult.text="Player 2 wins"
                  }else{
                      gameResult.text="Player 1 wins"
                  }

            }
        }


        tv1.setOnClickListener(){
            count++
            if(count%2==0)
            {
                tv1.text="X"
                game[0]="X"

            }else{
                tv1.text="0"
                game[0]="0"
            }
            checkWin()
        }

        tv2.setOnClickListener(){
            count++
            if(count%2==0){
                tv2.text="X";
                game[1]="X"
            }else{
                tv2.text="0"
                game[1]="0"
            }
            checkWin()
        }

        tv3.setOnClickListener(){
            count++
            if(count%2==0){
                tv3.text="X"
                game[2]="X"
            }else{
                tv3.text="0"
                game[2]="0"
            }
            checkWin()
        }

        tv4.setOnClickListener(){
            count++
            if(count%2==0){
                tv4.text="X"
                game[3]="X"
            }else{
                tv4.text="0"
                game[3]="0"
            }
            checkWin()
        }

        tv5.setOnClickListener(){
            count++;
            if(count%2==0){
                tv5.text="X"
                game[4]="X"
            }else{
                tv5.text="0"
                game[4]="0"

            }
            checkWin()
        }


        tv6.setOnClickListener(){
            count++;
            if(count%2==0){
                tv6.text="X"
                game[5]="X"
            }else{
                tv6.text="0"
                game[5]="0"
            }
            checkWin()
        }

        tv7.setOnClickListener(){
            count++;
            if(count%2==0){
                tv7.text="X"
                game[6]="X"
            }else{
                tv7.text="0"
                game[6]="0"
            }
            checkWin()
        }

        tv8.setOnClickListener(){
            count++
            if(count%2==0){
                tv8.text="X"
                game[7]="X"
            }else{
                tv8.text="0"
                game[7]="0"
            }
            checkWin()
        }

        tv9.setOnClickListener(){
            count++
            if(count%2==0){
                tv9.text="X"
                game[8]="X"
            }else{
                tv9.text="0"
                game[8]="0"
            }
            checkWin()
        }


        playBtn.setOnClickListener()
        {
            tv1.text="1"
            tv2.text="2"
            tv3.text="3"
            tv4.text="4"
            tv5.text="5"
            tv6.text="6"
            tv7.text="7"
            tv8.text="8"
            tv9.text="9"
            gameResult.text="winner will be announce here"
            game =arrayOf("1","2","3","4","5","6","7","8","9")
        }


    }
}