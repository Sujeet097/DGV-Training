package com.example.ractice

import androidx.lifecycle.ViewModel

class CategoryData : ViewModel() {


    var data = listOf<Category>(
        Category(1, R.drawable.samsung_s22,"samsung galaxy s22 is is 6 month old and I am selling it for 16000Rs","Vinay Pahwa","Samsung S22","mobile"),
        Category(2,R.drawable.redmi_note7pro,"samsung galaxy s22 is is 6 month old and I am selling it for 16000Rs","Sanjay Raut","Redmi Note 7","mobile"),
        Category( 3,R.drawable.realmenarzoo,"samsung galaxy s22 is is 6 month old and I am selling it for 16000Rs","Arjun Kapoor","RealMe Narzo30","mobile"),
        Category( 4,R.drawable.google_5a,"samsung galaxy s22 is is 6 month old and I am selling it for 16000Rs","Abhishek Jha","Google 5a","mobile"),
        Category( 5,R.drawable.iqoo_z6,"samsung galaxy s22 is is 6 month old and I am selling it for 16000Rs","Murli Vijay","Iqoo z6","mobile"),
        Category(6, R.drawable.samsung_s22,"samsung galaxy s22 is is 6 month old and I am selling it for 16000Rs","Raj Singh","Samsung S22","mobile"),
        Category(7,R.drawable.redmi_note7pro,"samsung galaxy s22 is is 6 month old and I am selling it for 16000Rs","George Emmanule","Redmi Note 7","mobile"),
        Category( 8,R.drawable.realmenarzoo,"samsung galaxy s22 is is 6 month old and I am selling it for 16000Rs","Harvardhan Rane","RealMe Narzo30","mobile"),
        Category( 9,R.drawable.google_5a,"samsung galaxy s22 is is 6 month old and I am selling it for 16000Rs","Nutann ","Google 5a","laptop"),
        Category( 10,R.drawable.iqoo_z6,"samsung galaxy s22 is is 6 month old and I am selling it for 16000Rs","Shweta Tiwari","Iqoo z6","laptop"),

        )

    var laptop= listOf<Category>(
        Category(11, R.drawable.acer_predator,"Acer predator is is 6 month old and I am selling it for 16000Rs","Sujeet Singh","Acer Predator","laptop"),
        Category(12,R.drawable.mi_notebook,"MI Notebook is is 6 month old and I am selling it for 16000Rs","Sanjay Raut","MI Notebook","laptop"),
        Category( 13,R.drawable.lenovo_ideapad,"Lenovo Ideapad is is 6 month old and I am selling it for 16000Rs","Varun kalra","Lenovo Ideapad","laptop"),
        Category( 14,R.drawable.lenovo_yoga,"Lenovo Yoga is is 6 month old and I am selling it for 16000Rs","Monica","Lenovo Yoga","laptop"),
        Category( 15,R.drawable.lenovo_ideapad,"Lenovo Ideapad is is 6 month old and I am selling it for 16000Rs","Damini","Lenovo","laptop"),
        Category(16, R.drawable.mi_notebook,"MI Notebook is is 6 month old and I am selling it for 16000Rs","Raj Singh","Mi Notebook","laptop"),
        Category(17,R.drawable.acer_predator,"Acer predator is is 6 month old and I am selling it for 16000Rs","George Emmanule","Acer Predator","laptop"),
        Category( 18,R.drawable.mi_notebook,"MI Notebook is is 6 month old and I am selling it for 16000Rs","Sarvesh Kathuria","Lenovo","laptop"),
        Category( 19,R.drawable.lenovo_ideapad,"samsung galaxy s22 is is 6 month old and I am selling it for 16000Rs","Nutann ","Dell Inspiron","laptop"),
        Category( 20,R.drawable.acer_predator,"Acer predator is is 6 month old and I am selling it for 16000Rs","Devansh Banga","Acer Predator","laptop"),
        )


    var tv= listOf<Category>(
        Category(21, R.drawable.samsung_tv,"Acer predator is is 6 month old and I am selling it for 16000Rs","Sujeet Singh","Samsung S22","laptop"),
        Category(22,R.drawable.hisense,"MI Notebook is is 6 month old and I am selling it for 16000Rs","Sanjay Raut","Redmi Note 7","laptop"),
        Category( 23,R.drawable.samsung_tv,"Lenovo Ideapad is is 6 month old and I am selling it for 16000Rs","Varun kalra","RealMe Narzo30","laptop"),
        Category( 24,R.drawable.videocon,"Lenovo Yoga is is 6 month old and I am selling it for 16000Rs","Monica","Google 5a","laptop"),
        Category( 25,R.drawable.hisense,"Lenovo Ideapad is is 6 month old and I am selling it for 16000Rs","Damini","Iqoo z6","laptop"),
        Category(26, R.drawable.samsung_tv,"MI Notebook is is 6 month old and I am selling it for 16000Rs","Raj Singh","Samsung S22","laptop"),
        Category(27,R.drawable.hisense,"Acer predator is is 6 month old and I am selling it for 16000Rs","George Emmanule","Redmi Note 7","laptop"),
        Category( 28,R.drawable.samsung_tv,"MI Notebook is is 6 month old and I am selling it for 16000Rs","Sarvesh Kathuria","RealMe Narzo30","laptop"),
        Category( 29,R.drawable.hisense,"samsung galaxy s22 is is 6 month old and I am selling it for 16000Rs","Nutann ","Google 5a","laptop"),
        Category( 30,R.drawable.videocon,"Acer predator is is 6 month old and I am selling it for 16000Rs","Devansh Banga","Iqoo z6","laptop"),
    )

    var genre= listOf<String>(
        "mobile",
        "laptop",
        "tv",
        "others"
    )
    }

