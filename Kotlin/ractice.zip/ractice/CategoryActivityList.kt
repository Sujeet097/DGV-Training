package com.example.ractice

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CategoryActivityList : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_list)

        val myrecylerView = findViewById<RecyclerView>(R.id.myrecylerView)
        val categoryData: CategoryData = ViewModelProvider(this).get(CategoryData::class.java)
        val name=intent.getStringExtra("name")

        //going to categories next activity


        lateinit var listAdapter:ListAdapter
        if(name=="laptop") {
             listAdapter = ListAdapter(this, categoryData.laptop)
        }else if(name=="data") {
            listAdapter = ListAdapter(this, categoryData.data)
        }
        else if(name=="tv") {
            listAdapter = ListAdapter(this, categoryData.tv)
        }
        myrecylerView.adapter = listAdapter



        myrecylerView.layoutManager = LinearLayoutManager(this)


    }
}