package com.example.ractice

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.snackbar.Snackbar

class CategoryListDetails : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_list_details)

        val categoryData: CategoryData = ViewModelProvider(this).get(CategoryData::class.java)
//        val category: CategoryData = ViewModelProvider(this).get(CategoryData::class.java)


        var index = intent.getStringExtra("id")
        var cdata:Category = categoryData.data.get(index!!.toInt())

        //Fetching Details
        val thumbnail = findViewById<ImageView>(R.id.thumbnail)
        val mbowner = findViewById<TextView>(R.id.mbowner)
        val mbname = findViewById<TextView>(R.id.mbname)
        val cobtn = findViewById<Button>(R.id.cobtn)
        val description = findViewById<TextView>(R.id.description)
        
        thumbnail.setImageResource(cdata.img)
        mbowner.text = cdata.mowner
        mbname.text =cdata.mname
        description.text = cdata.description

        //Getting the notification that owner will contact you when you click contact owner button

        cobtn.setOnClickListener(){
         var snackbar = Snackbar.make(cobtn,"The owner will contact you soon",Snackbar.LENGTH_LONG)
            snackbar.show()

        }

    }
}