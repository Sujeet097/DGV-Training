package com.example.ractice

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView

class ListAdapter(val context : Context, val category : List<Category>): RecyclerView.Adapter<ListAdapter.ViewHolder>() {


    //Creating Layout to inflate
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(context).inflate(R.layout.list_item,parent,false)
        )
    }
     //Binding layout data to send
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val cdata=category.get(position)
        holder.mowner.text = cdata.mowner
        holder.mname.text=cdata.mname
        holder.img.setImageResource(cdata.img)

        holder.cl.setOnClickListener{
            val intent = Intent(context, CategoryListDetails::class.java)
            intent.putExtra("id", cdata.id.toString())
            context.startActivity(intent)
        }

    }
    override fun getItemCount(): Int {
        return  category.size
    }

    class ViewHolder(view: View): RecyclerView.ViewHolder(view) {

        val img = view.findViewById<ImageView>(R.id.img)
        val mowner = view.findViewById<TextView>(R.id.mowner)
        val mname = view.findViewById<TextView>(R.id.mname)
        val cl = view.findViewById<ConstraintLayout>(R.id.cl)
    }




}