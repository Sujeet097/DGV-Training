package com.example.ractice

class Category(id:Int,img:Int,description:String,mowner:String,mname:String,genre:String) {

    var id:Int?=0
    var img:Int=0
    var description:String?=null
    var mowner:String?=null
    var mname:String?=null
    var genre:String?=null

    init {
        this.id=id
        this.img=img
        this.description=description
        this.mowner=mowner
        this.mname=mname
        this.genre=genre
    }


}