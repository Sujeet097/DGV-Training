package com.example.ractice

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //Going to main Activity
        val buy = findViewById<TextView>(R.id.buy)
        buy.setOnClickListener() {
            val intent = Intent(MainActivity@ this, CategoryActivity::class.java)
            startActivity(intent)
        }

        val sell = findViewById<TextView>(R.id.sell)
        sell.setOnClickListener() {
            val intent = Intent(MainActivity@ this, SellActivity::class.java)
            startActivity(intent)
        }
    }
}