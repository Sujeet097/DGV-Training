package com.example.ractice

import android.content.ContentValues
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class SellActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sell)


        //Fetching Data
        var name =findViewById<EditText>(R.id.name)
        var email =findViewById<EditText>(R.id.email)
        var place =findViewById<EditText>(R.id.place)
        var smbtn= findViewById<Button>(R.id.smbtn)

        var helper =DBHelper(applicationContext)
        var db = helper.readableDatabase
        /*var rs=db.rawQuery("SELECT * FROM USERS",null)
*/
        //clicking on submit button that submit the data to the sqlite database
        smbtn.setOnClickListener(){
            var cv= ContentValues()
            cv.put("UNAME",name.text.toString())
            cv.put("UEMAIL",email.text.toString())
            cv.put("UPLACE",place.text.toString())

            //Toast message that data is inserted
            Toast.makeText(this,"Sucessfully submitted",Toast.LENGTH_LONG).show()

            //clear the form after submitting
            name.text.clear()
            email.text.clear()
            place.text.clear()
        }
    }
}